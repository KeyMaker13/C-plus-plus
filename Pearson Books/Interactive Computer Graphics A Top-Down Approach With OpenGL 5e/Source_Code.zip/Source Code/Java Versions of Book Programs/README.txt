The zip file is this directory contains the Java versions of
the sample programs in Angel: Interactive Computer Graphics,
Fourth Addition. They use the JOGL implementation of OpenGL
(included). The zip file also contains the necessary make files
for Linux and Windows.

Programs converted by Takeshi Hakamata.
