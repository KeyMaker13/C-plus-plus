Thus folder contains the following C programs for Chapter 12:

bteapot: recursive rendering of Utah teapot from data in patches.c and vertices.c

curves.c: interactive drawing of Interpolating, Bezier, and Spline curves
