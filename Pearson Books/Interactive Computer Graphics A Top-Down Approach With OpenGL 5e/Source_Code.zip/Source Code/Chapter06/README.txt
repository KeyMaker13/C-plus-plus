This directory contains the following C program for Chapter 6:

sphere.c: sphere approximation by recursive subdivision displayed
with three different shading methods

