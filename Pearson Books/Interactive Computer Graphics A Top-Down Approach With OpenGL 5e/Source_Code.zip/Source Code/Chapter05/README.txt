This directory contains the following C programs for Chapter 5

cubeview.c: cube viewing program using the keyboard

shadow.c: illustrates projective shadow from a single polygon
