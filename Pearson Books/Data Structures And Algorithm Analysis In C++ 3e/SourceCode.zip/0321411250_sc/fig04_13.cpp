        struct BinaryNode
        {
            Object      element;      // The data in the node
            BinaryNode *left;         // Left child
            BinaryNode *right;        // Right child
        };
