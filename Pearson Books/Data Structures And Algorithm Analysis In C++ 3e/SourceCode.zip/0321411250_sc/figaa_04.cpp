{text}
#include "MemoryCell.cpp"

template class MemoryCell<int>;
template class MemoryCell<double>;
