#ifndef MEMORY_CELL_H
#define MEMORY_CELL_H

template <typename Object>
export class MemoryCell
{
